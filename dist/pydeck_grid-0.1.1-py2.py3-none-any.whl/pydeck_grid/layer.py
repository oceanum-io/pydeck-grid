import orjson

import xarray as xr
import numpy as np
from matplotlib.cm import ScalarMappable, get_cmap
from matplotlib.colors import Normalize, rgb2hex, hex2color


from pydeck.bindings.layer import Layer
from pydeck.types.base import PydeckType
from pydeck.bindings.json_tools import JSONMixin, default_serialize

import pydeck

from .legend import colorbar_div

pydeck.settings.custom_libraries = [
    {
        "libraryName": "DeckGriddedLayers",
        # "resourceUri": "https://assets.oceanum.io/packages/deck-gl-grid/bundle.umd.cjs",
        "resourceUri": "http://localhost:3001/dist/bundle.umd.cjs",
    }
]


def sanitize_color(color):
    if isinstance(color, str):
        if color.startswith("#"):
            color = [255 * c for c in hex2color(color)]
    return color


def orjson_serializer(serializable):
    return orjson.dumps(
        serializable,
        option=orjson.OPT_SERIALIZE_NUMPY,
        default=default_serialize,
    ).decode("utf-8")


JSONMixin.to_json = orjson_serializer


class GridLayerData(dict):
    def __init__(self, data, datakeys):
        _data = {"coords": {}, "data_vars": {}}
        for v in datakeys.values():
            if v in data.coords:
                arr = data.coords[v].values
                if not arr.data.contiguous:
                    arr = np.ascontiguousarray(arr)
                _data["coords"][v] = {"data": arr}
            else:
                _data["data_vars"][v] = {"data": data.data_vars[v].values}
        super().__init__(_data)


class GridColormap(dict):
    def __init__(self, colormap, vmin, vmax):
        if colormap and isinstance(colormap, str):
            colormap = ScalarMappable(Normalize(vmin, vmax), get_cmap(colormap))
        if not isinstance(colormap, ScalarMappable):
            raise GridLayerException(
                "colormap must be a matplotlib colormap name or a ScalarMappable"
            )
        super().__init__(
            {
                "scale": [rgb2hex(c) for c in colormap.cmap.colors],
                "domain": [vmin, vmax],
            }
        )


class GridLayerException(Exception):
    pass


class GridLayer(Layer):
    def __init__(
        self,
        type,
        data,
        datakeys,
        id=None,
        colormap=None,
        vmin=0.0,
        vmax=1.0,
        **kwargs,
    ):
        """Configures a deck.gl layer for rendering gridded data on a map. Parameters passed
        here will be specific to the particular deck.gl grid layer that you are choosing to use.
        """

        if not isinstance(data, xr.Dataset):
            raise GridLayerException("Data must be an xarray DataSet")
        if datakeys["x"] not in data.coords:
            raise GridLayerException(f"x coordinate {datakeys['x']} not in data")
        if datakeys["y"] not in data.coords:
            raise GridLayerException(f"y coordinate {datakeys['y']} not in data")
        if len(data.coords[datakeys["x"]].dims) > 1:
            raise GridLayerException(f"x coordinate {datakeys['x']} is not 1D")
        if len(data.coords[datakeys["y"]].dims) > 1:
            raise GridLayerException(f"y coordinate {datakeys['y']} is not 1D")

        self.grid_colormap = GridColormap(colormap, vmin, vmax) if colormap else None

        # Take first 2D grid from the data array
        ndims = len(data.dims)
        if ndims < 2:
            raise GridLayerException("Layer data must be at least 2D")
        indexer = {
            i: 0
            for i in data.dims
            if i
            not in [datakeys["x"], datakeys["y"]] + ["b" in datakeys and datakeys["b"]]
        }
        griddata = GridLayerData(data.isel(**indexer, drop=True), datakeys)

        super().__init__(
            type,
            griddata,
            id,
            use_binary_transport=False,
            colormap=self.grid_colormap,
            datakeys=datakeys,
            **kwargs,
        )

    def colorbar(
        self,
        labels=None,
        units=None,
        width=200,
        height=40,
        labelcolor="white",
    ):
        """Return a colorbar for the layer to use in the pydeck description

        Parameters
        ==========
        labels: list, optional
            List of labels to use for the colorbar
        units: str, optional
            Units string to use for the colorbar
        width: int, optional
            Width of the colorbar in pixels
        height: int, optional
            Height of the colorbar in pixels
        labelcolor: str, optional
            Color of the colorbar labels
        """

        return colorbar_div(
            self.grid_colormap,
            labels=labels,
            units=units,
            width=width,
            height=height,
            labelcolor=labelcolor,
        )
